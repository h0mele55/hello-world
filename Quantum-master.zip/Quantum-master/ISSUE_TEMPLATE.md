
## THANKS FOR TAKING THE TIME TO REPORT AN ISSUE ##

Please be advised that we are collecting feedback for the entire 
Microsoft Quantum Development Kit at [user voice](https://quantum.uservoice.com/). 

It would be much better for us if you  leave your suggestions,
requests and bugs (or praises!) there.

Thanks!
